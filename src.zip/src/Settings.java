public class Settings {
    public final static int cpuCoresPlusOne = Runtime.getRuntime().availableProcessors() + 1;
}
